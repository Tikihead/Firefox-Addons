
 function openMyPage()
{  console.log("injecting");
         browser.tabs.create({
         "url": "https://s.codepen.io/Xiija/full/vRXJgx/yPkJjGzDGzwk",
         active: true
         });
}
/*
 Add openMyPage() as a listener to clicks on the browser action.
*/
browser.browserAction.onClicked.addListener(openMyPage);





